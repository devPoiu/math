function sum(mat1, mat2){
    let mat3 = []
    for (let i = 0; i < mat1.length; i++){
        mat3[i] = []
        for (let j = 0; j < mat1[i].length; j++){
            mat3[i][j] = mat1[i][j] + mat2[i][j]
        }
    }
}

function minis(mat1, mat2){
    let mat3 = []
    for (let i = 0; i < mat1.length; i++){
        mat3[i] = []
        for (let j = 0; j < mat1[i].length; j++){
            mat3[i][j] = mat1[i][j] - mat2[i][j]
        }
    }
}

function mul(mat1, mat2){
    let mat3 = []
    let m = mat1[0].length
    let k = mat2.length
    for (let i = 0; i < k; i++){
        mat3[i] = []
        for (let j = 0; j < m; j++){
            let arr1 = []
            let arr2 = []
            for (let q = 0; q < mat1.length; q++){
                
            }
        }
    }
}

sum([[2,1],[3,4]], [[1,2],[4,3]])