function sum(mat1, mat2){
    let mat3 = []
    for (let i = 0; i < mat1.length; i++){
        mat3[i] = []
        for (let j = 0; j < mat1[i].length; j++){
            mat3[i][j] = mat1[i][j] + mat2[i][j]
        }
    }
    return mat3
}

function minis(mat1, mat2){
    let mat3 = []
    for (let i = 0; i < mat1.length; i++){
        mat3[i] = []
        for (let j = 0; j < mat1[i].length; j++){
            mat3[i][j] = mat1[i][j] - mat2[i][j]
        }
    }
}

function mul(mat1, mat2) {
    let mat3 = []
    let rows1 = mat1.length
    let cols1 = mat1[0].length
    let cols2 = mat2[0].length

    for (let i = 0; i < rows1; i++) {
        mat3[i] = []
        for (let j = 0; j < cols2; j++) {
            let sum = 0
            for (let q = 0; q < cols1; q++) {
                sum += mat1[i][q] * mat2[q][j]
            }
            mat3[i][j] = sum
        }
    }
    return mat3
}

function opred(mat) {
    const n = mat.length
    if (n === 1) {
        return mat[0][0]
    }
    if (n === 2) {
        return mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0]
    }
    let det = 0

    for (let j = 0; j < n; j++) {
        let subMat = []
        for (let row = 1; row < n; row++) {
            let minbRow = []
            for (let col = 0; col < n; col++) {
                if (col !== j) {
                    minbRow.push(mat[row][col])
                }
            }
            subMat.push(minbRow)
        }
        let sign = Math.pow(-1, j)
        det += sign * mat[0][j] * opred(subMat)
    }

    return det;
}


function minor(mat, m, k){
    let minor =[]
    for (let i = 0; i < mat.length; i++){
        if (i === m) continue
        let row = []
        for (let j = 0; j < mat[i].length; j++){
            if (j === k) continue
            row.push(mat[i][j])
        }
        minor.push(row)
    }
    return minor
}



// sum([[2,1],[3,4]], [[1,2],[4,3]])
// mul([[1,2],
//      [3,4],
//      [5,6]],

//     [[5,6,7],
//      [8,9,0]])

     
console.log(opred([[0,1,0],
                   [3,4,4],
                   [5,6,4]]))